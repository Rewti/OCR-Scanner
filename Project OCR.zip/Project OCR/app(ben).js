const express = require("express");
const app = express();
const fs = require("fs");
const path = require("path");
const multer = require("multer");
const {createWorker} = require("tesseract.js");
const worker = createWorker();

const storage =multer.diskStorage({
    destination:(req,file,cb)=>{
        cb(null,"./assets");
    },
    filename: (req,file,cb)=>{
        cb(null,file.originalname);
    },
});

const uploadController = multer({storage:storage}).single("ocrfile");

app.set("view engine","ejs");
app.get("/",(req,res)=>{
    res.render("index");
});

app.post("/upload",(req,res)=>{
    uploadController(req,res,(err)=>{
        fs.readFile(`./assets/${req.file.originalname}`,(err,data)=>{
            if(err) return console.log("this is error:",err);
            (async ()=>{
                await worker.load();
                await worker.loadLanguage("ben");
                await worker.initialize("ben");
                await worker.recognize(data);
                const {data:pdfData}= await worker.getPDF("OCR Result");
                fs.writeFileSync(`${req.file.originalname}.pdf`,Buffer.from(pdfData));
                await worker.terminate();
                let pdffile = path.join(__dirname,`${req.file.originalname}.pdf`);
                res.download(pdffile);
            })();
        });
    });
});

app.listen(5000,()=>console.log("Application is Started"));